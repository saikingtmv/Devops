/* ══════════════════════════════════════════════
   PORTFOLIO – MAIN.JS
   ══════════════════════════════════════════════ */

"use strict";

// ── Set current year in footer ──────────────────
document.getElementById("year").textContent = new Date().getFullYear();

// ══════════════════════════════════════════════
// NAVBAR – scroll shrink + active link
// ══════════════════════════════════════════════
const navbar    = document.getElementById("navbar");
const navLinks  = document.querySelectorAll(".nav-link");
const sections  = document.querySelectorAll("section[id]");
const hamburger = document.getElementById("hamburger");
const navList   = document.querySelector(".nav-links");

window.addEventListener("scroll", () => {
  // Shrink navbar
  navbar.classList.toggle("scrolled", window.scrollY > 60);

  // Active link highlighting
  let current = "";
  sections.forEach(sec => {
    if (window.scrollY >= sec.offsetTop - 120) current = sec.getAttribute("id");
  });
  navLinks.forEach(link => {
    link.classList.toggle("active", link.getAttribute("href") === `#${current}`);
  });
}, { passive: true });

// Hamburger menu
hamburger.addEventListener("click", () => {
  hamburger.classList.toggle("open");
  navList.classList.toggle("open");
});

navLinks.forEach(link => {
  link.addEventListener("click", () => {
    hamburger.classList.remove("open");
    navList.classList.remove("open");
  });
});

// ══════════════════════════════════════════════
// TYPING EFFECT
// ══════════════════════════════════════════════
(function initTyping() {
  const el    = document.getElementById("typing-text");
  const texts = window.TYPING_TEXTS || ["Developer"];
  let   ti    = 0;      // text index
  let   ci    = 0;      // char index
  let   del   = false;  // deleting?

  function tick() {
    const full = texts[ti];
    el.textContent = del ? full.slice(0, ci--) : full.slice(0, ci++);

    let delay = del ? 60 : 110;

    if (!del && ci > full.length) {
      del   = true;
      delay = 1800;
    } else if (del && ci < 0) {
      del   = false;
      ti    = (ti + 1) % texts.length;
      ci    = 0;
      delay = 400;
    }

    setTimeout(tick, delay);
  }

  tick();
})();

// ══════════════════════════════════════════════
// SCROLL REVEAL
// ══════════════════════════════════════════════
(function initReveal() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry, idx) => {
        if (entry.isIntersecting) {
          // Staggered delay for sibling cards
          const siblings = Array.from(entry.target.parentElement.children)
            .filter(el => el.classList.contains("reveal"));
          const siblIdx  = siblings.indexOf(entry.target);
          const delay    = siblIdx * 80;

          setTimeout(() => entry.target.classList.add("visible"), delay);
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -50px 0px" }
  );

  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
})();

// ══════════════════════════════════════════════
// SKILL BARS  – animate when visible
// ══════════════════════════════════════════════
(function initSkillBars() {
  const fills = document.querySelectorAll(".skill-bar-fill");

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const bar   = entry.target;
          const level = bar.getAttribute("data-level");
          bar.style.width = level + "%";
          observer.unobserve(bar);
        }
      });
    },
    { threshold: 0.3 }
  );

  fills.forEach(fill => observer.observe(fill));
})();

// ══════════════════════════════════════════════
// COUNTER – animated stat numbers
// ══════════════════════════════════════════════
(function initCounters() {
  const counters = document.querySelectorAll(".stat-num[data-target]");

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el     = entry.target;
        const target = parseInt(el.getAttribute("data-target"), 10);
        const dur    = 1600;
        const step   = dur / target;
        let   current = 0;

        const timer = setInterval(() => {
          current++;
          el.textContent = current;
          if (current >= target) clearInterval(timer);
        }, step);

        observer.unobserve(el);
      });
    },
    { threshold: 0.5 }
  );

  counters.forEach(c => observer.observe(c));
})();

// ══════════════════════════════════════════════
// PARTICLES.JS CONFIG
// ══════════════════════════════════════════════
if (window.particlesJS) {
  particlesJS("particles-js", {
    particles: {
      number:   { value: 70, density: { enable: true, value_area: 900 } },
      color:    { value: ["#6c63ff", "#a78bfa", "#38bdf8"] },
      shape:    { type: "circle" },
      opacity:  { value: 0.5, random: true, anim: { enable: true, speed: 1, opacity_min: 0.1 } },
      size:     { value: 3, random: true, anim: { enable: true, speed: 2, size_min: 0.5 } },
      line_linked: {
        enable:   true,
        distance: 150,
        color:    "#6c63ff",
        opacity:  0.18,
        width:    1
      },
      move: {
        enable:    true,
        speed:     1.2,
        direction: "none",
        random:    true,
        straight:  false,
        out_mode:  "out",
        bounce:    false
      }
    },
    interactivity: {
      detect_on: "canvas",
      events: {
        onhover: { enable: true,  mode: "grab" },
        onclick:  { enable: true,  mode: "push" },
        resize:   true
      },
      modes: {
        grab:  { distance: 140, line_linked: { opacity: 0.5 } },
        push:  { particles_nb: 3 }
      }
    },
    retina_detect: true
  });
}

// ══════════════════════════════════════════════
// CONTACT FORM – fetch POST
// ══════════════════════════════════════════════
(function initContactForm() {
  const form      = document.getElementById("contact-form");
  const statusEl  = document.getElementById("form-status");
  const submitBtn = document.getElementById("submit-btn");

  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    statusEl.className  = "form-status";
    statusEl.style.display = "none";

    const name    = form.name.value.trim();
    const email   = form.email.value.trim();
    const message = form.message.value.trim();

    // Basic client-side validation
    if (!name || !email || !message) {
      showStatus("error", "Please fill in all fields.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showStatus("error", "Please enter a valid email address.");
      return;
    }

    submitBtn.classList.add("loading");

    try {
      const res  = await fetch("/contact", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ name, email, message })
      });
      const data = await res.json();

      if (data.success) {
        showStatus("success", data.message);
        form.reset();
      } else {
        showStatus("error", data.error || "Something went wrong. Please try again.");
      }
    } catch {
      showStatus("error", "Network error – please check your connection.");
    } finally {
      submitBtn.classList.remove("loading");
    }
  });

  function showStatus(type, msg) {
    statusEl.textContent  = msg;
    statusEl.className    = `form-status ${type}`;
    statusEl.style.display = "block";
    statusEl.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
})();

// ══════════════════════════════════════════════
// PROJECT CARD TILT EFFECT
// ══════════════════════════════════════════════
document.querySelectorAll(".project-card").forEach(card => {
  card.addEventListener("mousemove", (e) => {
    const rect   = card.getBoundingClientRect();
    const x      = ((e.clientX - rect.left) / rect.width  - 0.5) * 12;
    const y      = ((e.clientY - rect.top)  / rect.height - 0.5) * 12;
    card.style.transform = `perspective(600px) rotateY(${x}deg) rotateX(${-y}deg) translateY(-8px)`;
  });

  card.addEventListener("mouseleave", () => {
    card.style.transform = "";
  });
});

// ══════════════════════════════════════════════
// GLOBE ANIMATION (Three.js)
// ══════════════════════════════════════════════
(function initGlobe() {
  if (typeof THREE === "undefined") return;
  const canvas = document.getElementById("globe-canvas");
  if (!canvas) return;

  const W = canvas.offsetWidth  || 520;
  const H = canvas.offsetHeight || 520;

  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(W, H);

  const scene  = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, W / H, 0.1, 1000);
  camera.position.z = 2.6;

  // ── Globe wireframe sphere ──
  const sphereGeo  = new THREE.SphereGeometry(1, 48, 48);
  const wireGeo    = new THREE.WireframeGeometry(sphereGeo);
  const wireMat    = new THREE.LineBasicMaterial({ color: 0x6c63ff, transparent: true, opacity: 0.18 });
  const wireframe  = new THREE.LineSegments(wireGeo, wireMat);
  scene.add(wireframe);

  // ── Glowing solid sphere ──
  const glowMat = new THREE.MeshBasicMaterial({
    color: 0x1a1040,
    transparent: true,
    opacity: 0.55
  });
  const glowMesh = new THREE.Mesh(sphereGeo, glowMat);
  scene.add(glowMesh);

  // ── Scattered dot points on surface ──
  const dotCount  = 320;
  const dotGeo    = new THREE.BufferGeometry();
  const positions = [];
  const colors    = [];
  const palette   = [
    new THREE.Color(0x6c63ff),
    new THREE.Color(0x38bdf8),
    new THREE.Color(0xa78bfa),
    new THREE.Color(0xfbbf24),
  ];

  for (let i = 0; i < dotCount; i++) {
    const phi   = Math.acos(2 * Math.random() - 1);
    const theta = 2 * Math.PI * Math.random();
    const r     = 1.01;
    positions.push(
      r * Math.sin(phi) * Math.cos(theta),
      r * Math.sin(phi) * Math.sin(theta),
      r * Math.cos(phi)
    );
    const c = palette[Math.floor(Math.random() * palette.length)];
    colors.push(c.r, c.g, c.b);
  }

  dotGeo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  dotGeo.setAttribute("color",    new THREE.Float32BufferAttribute(colors, 3));
  const dotMat  = new THREE.PointsMaterial({ size: 0.028, vertexColors: true, transparent: true, opacity: 0.85 });
  const dotMesh = new THREE.Points(dotGeo, dotMat);
  scene.add(dotMesh);

  // ── Arc lines between random dot pairs ──
  const arcGroup = new THREE.Group();
  scene.add(arcGroup);

  function makeArc(p1, p2, col) {
    const mid = new THREE.Vector3().addVectors(p1, p2).multiplyScalar(0.5).normalize().multiplyScalar(1.35);
    const curve = new THREE.QuadraticBezierCurve3(p1, mid, p2);
    const pts   = curve.getPoints(40);
    const geo   = new THREE.BufferGeometry().setFromPoints(pts);
    const mat   = new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.4 });
    return new THREE.Line(geo, mat);
  }

  const pos = dotGeo.attributes.position;
  for (let i = 0; i < 18; i++) {
    const ai = Math.floor(Math.random() * dotCount);
    const bi = Math.floor(Math.random() * dotCount);
    const p1 = new THREE.Vector3(pos.getX(ai), pos.getY(ai), pos.getZ(ai));
    const p2 = new THREE.Vector3(pos.getX(bi), pos.getY(bi), pos.getZ(bi));
    const col = palette[Math.floor(Math.random() * palette.length)];
    arcGroup.add(makeArc(p1, p2, col));
  }

  // ── Outer glow ring ──
  const ringGeo = new THREE.TorusGeometry(1.08, 0.003, 2, 120);
  const ringMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.35 });
  const ring    = new THREE.Mesh(ringGeo, ringMat);
  ring.rotation.x = Math.PI / 4;
  scene.add(ring);

  // ── Mouse parallax ──
  let mouseX = 0, mouseY = 0;
  document.addEventListener("mousemove", (e) => {
    mouseX = (e.clientX / window.innerWidth  - 0.5) * 0.6;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 0.6;
  });

  // ── Animate ──
  let t = 0;
  function animate() {
    requestAnimationFrame(animate);
    t += 0.004;

    wireframe.rotation.y += 0.0018;
    wireframe.rotation.x  = mouseY * 0.4;
    wireframe.rotation.y += mouseX * 0.002;

    glowMesh.rotation.y = wireframe.rotation.y;
    glowMesh.rotation.x = wireframe.rotation.x;

    dotMesh.rotation.y = wireframe.rotation.y;
    dotMesh.rotation.x = wireframe.rotation.x;

    arcGroup.rotation.y = wireframe.rotation.y;
    arcGroup.rotation.x = wireframe.rotation.x;

    ring.rotation.y += 0.005;
    ring.rotation.z  = Math.sin(t) * 0.15;

    // Pulse dot opacity
    dotMat.opacity = 0.65 + Math.sin(t * 2) * 0.2;

    renderer.render(scene, camera);
  }
  animate();

  // ── Resize ──
  window.addEventListener("resize", () => {
    const nw = canvas.offsetWidth;
    const nh = canvas.offsetHeight;
    camera.aspect = nw / nh;
    camera.updateProjectionMatrix();
    renderer.setSize(nw, nh);
  });
})();

// ══════════════════════════════════════════════
// NEURAL NETWORK ANIMATION
// ══════════════════════════════════════════════
(function initSpine() {
  const canvas = document.getElementById("spine-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  let W, H, mouse = { x: -9999, y: -9999 };

  function resize() {
    W = canvas.width  = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener("resize", () => { resize(); init(); });

  document.addEventListener("mousemove", e => {
    const r = canvas.getBoundingClientRect();
    mouse.x = e.clientX - r.left;
    mouse.y = e.clientY - r.top;
  });

  // ── Colour palette ──
  const PALETTE = ["#6c63ff","#38bdf8","#a78bfa","#f472b6","#4ade80","#fbbf24"];

  // ── Nodes ──
  let nodes = [];
  const NODE_COUNT = 55;

  function randomColor() { return PALETTE[Math.floor(Math.random() * PALETTE.length)]; }

  function init() {
    nodes = Array.from({ length: NODE_COUNT }, (_, i) => ({
      x:     Math.random() * W,
      y:     Math.random() * H,
      vx:    (Math.random() - 0.5) * 0.45,
      vy:    (Math.random() - 0.5) * 0.45,
      r:     2.5 + Math.random() * 3.5,
      color: randomColor(),
      phase: Math.random() * Math.PI * 2,
      // extra "anchor" nodes that barely move for a stable spine feel
      fixed: i < 10,
    }));
    // Place first 10 as a loose vertical spine on the left third
    nodes.slice(0, 10).forEach((n, i) => {
      n.x  = W * 0.08 + Math.random() * W * 0.32;
      n.y  = H * 0.06 + (H * 0.88 / 9) * i + (Math.random() - 0.5) * 40;
      n.vx = (Math.random() - 0.5) * 0.15;
      n.vy = (Math.random() - 0.5) * 0.15;
      n.r  = 4 + Math.random() * 4;
    });
  }
  init();

  // ── Signals ──
  const MAX_SIGNALS = 24;
  let signals = [];

  function spawnSignal(ax, ay, bx, by, col) {
    signals.push({ ax, ay, bx, by, t: 0, speed: 0.008 + Math.random() * 0.012, color: col, size: 3 + Math.random() * 2 });
  }

  // ── Connection distance ──
  const MAX_DIST = 160;

  let t = 0;

  function draw() {
    requestAnimationFrame(draw);
    t += 0.012;
    ctx.clearRect(0, 0, W, H);

    // ── Move nodes ──
    nodes.forEach(n => {
      n.x += n.vx;
      n.y += n.vy;
      // mouse repulsion
      const dx = n.x - mouse.x, dy = n.y - mouse.y;
      const dist = Math.sqrt(dx*dx + dy*dy);
      if (dist < 120) { n.vx += (dx / dist) * 0.4; n.vy += (dy / dist) * 0.4; }
      // dampen
      n.vx *= 0.98; n.vy *= 0.98;
      // bounce
      if (n.x < 0 || n.x > W) n.vx *= -1;
      if (n.y < 0 || n.y > H) n.vy *= -1;
      n.x = Math.max(0, Math.min(W, n.x));
      n.y = Math.max(0, Math.min(H, n.y));
    });

    // ── Draw connections ──
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i], b = nodes[j];
        const dx = a.x - b.x, dy = a.y - b.y;
        const d  = Math.sqrt(dx*dx + dy*dy);
        if (d > MAX_DIST) continue;
        const alpha = (1 - d / MAX_DIST) * 0.45;

        // Gradient line
        const g = ctx.createLinearGradient(a.x, a.y, b.x, b.y);
        g.addColorStop(0, hexA(a.color, alpha));
        g.addColorStop(1, hexA(b.color, alpha));
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.strokeStyle = g;
        ctx.lineWidth   = 1.2 * (1 - d / MAX_DIST);
        ctx.stroke();

        // Occasionally spawn signal
        if (Math.random() < 0.0008 && signals.length < MAX_SIGNALS) {
          spawnSignal(a.x, a.y, b.x, b.y, Math.random() < 0.5 ? a.color : b.color);
        }
      }
    }

    // ── Draw nodes ──
    nodes.forEach(n => {
      const pulse = 0.5 + 0.5 * Math.sin(t * 2 + n.phase);
      const r     = n.r * (1 + pulse * 0.4);

      // Outer halo
      const halo = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, r * 5);
      halo.addColorStop(0,   hexA(n.color, 0.25 * pulse));
      halo.addColorStop(0.5, hexA(n.color, 0.08 * pulse));
      halo.addColorStop(1,   hexA(n.color, 0));
      ctx.beginPath();
      ctx.arc(n.x, n.y, r * 5, 0, Math.PI * 2);
      ctx.fillStyle = halo;
      ctx.fill();

      // Ring
      ctx.beginPath();
      ctx.arc(n.x, n.y, r + 2, 0, Math.PI * 2);
      ctx.strokeStyle = hexA(n.color, 0.35 * pulse);
      ctx.lineWidth   = 1;
      ctx.stroke();

      // Core
      const core = ctx.createRadialGradient(n.x - r * 0.3, n.y - r * 0.3, 0, n.x, n.y, r);
      core.addColorStop(0, "#ffffff");
      core.addColorStop(0.4, n.color);
      core.addColorStop(1,   hexA(n.color, 0.5));
      ctx.beginPath();
      ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
      ctx.fillStyle   = core;
      ctx.shadowBlur  = 18;
      ctx.shadowColor = n.color;
      ctx.fill();
      ctx.shadowBlur  = 0;
    });

    // ── Draw signals ──
    signals = signals.filter(s => s.t <= 1);
    signals.forEach(s => {
      s.t += s.speed;
      const x = s.ax + (s.bx - s.ax) * s.t;
      const y = s.ay + (s.by - s.ay) * s.t;

      // Trail
      const trail = ctx.createRadialGradient(x, y, 0, x, y, s.size * 6);
      trail.addColorStop(0,   hexA(s.color, 0.8));
      trail.addColorStop(0.4, hexA(s.color, 0.25));
      trail.addColorStop(1,   hexA(s.color, 0));
      ctx.beginPath();
      ctx.arc(x, y, s.size * 6, 0, Math.PI * 2);
      ctx.fillStyle = trail;
      ctx.fill();

      // Bright dot
      ctx.beginPath();
      ctx.arc(x, y, s.size, 0, Math.PI * 2);
      ctx.fillStyle   = "#fff";
      ctx.shadowBlur  = 20;
      ctx.shadowColor = s.color;
      ctx.fill();
      ctx.shadowBlur  = 0;
    });
  }

  draw();

  function hexA(hex, alpha) {
    const r = parseInt(hex.slice(1,3), 16);
    const g = parseInt(hex.slice(3,5), 16);
    const b = parseInt(hex.slice(5,7), 16);
    return `rgba(${r},${g},${b},${alpha.toFixed(3)})`;
  }
})();
