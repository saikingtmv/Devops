from flask import Flask, render_template, request, jsonify
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
import re
from dotenv import load_dotenv

load_dotenv(override=True)

def get_smtp_creds():
    """Re-read .env on every call so changes take effect without restart."""
    load_dotenv(override=True)
    return os.environ.get("GMAIL_USER"), os.environ.get("GMAIL_APP_PASS")

app = Flask(__name__)

PORTFOLIO_DATA = {
    "name": "Saikumar Thangalla",
    "title": "Full Stack Developer | Cloud Solution Architect | Data and AI Engineer | Prompt Engineer",
    "taglines": ["Cloud Solution Architect", "Data and AI Engineer", "Prompt Engineer", "Full Stack Developer"],
    "about": (
        "Cloud Architect and Data Engineer with 8+ years of experience across AWS, Azure, "
        "and hybrid cloud environments. I specialise in building scalable infrastructure, "
        "automating data pipelines, and delivering AI-powered solutions that drive real business value. "
        "Passionate about clean architecture, cost optimisation, and turning complex problems into simple, elegant systems."
    ),
    "email": "saikumart9021@gmail.com",
    "github": "https://github.com/S566629",
    "linkedin": "https://linkedin.com/in/saikumarthangalla",
    "twitter": "https://twitter.com/saikumarthangalla",
    "skills": [
        {"name": "Azure Cloud Architecture",          "level": 95},
        {"name": "Python / Flask / Django / FastAPI", "level": 92},
        {"name": "Terraform / Bicep / IaC",           "level": 90},
        {"name": "Docker / Kubernetes / CI-CD",       "level": 88},
        {"name": "Data Pipelines / Microsoft Fabric", "level": 85},
        {"name": "JavaScript / React / Vue / Node",   "level": 82},
    ],
    "skill_categories": [
        {
            "name": "Cloud Platforms",
            "icon": "fas fa-cloud",
            "color": "blue",
            "skills": [
                "Microsoft Azure", "Amazon AWS", "Azure AKS", "Azure Synapse Analytics",
                "Azure Data Factory", "Microsoft Fabric", "Azure DevOps", "Azure Functions",
                "AWS Lambda", "AWS Glue", "AWS S3", "CloudFormation", "Azure Monitor", "Azure SQL",
            ],
        },
        {
            "name": "DevOps & IaC",
            "icon": "fas fa-infinity",
            "color": "purple",
            "skills": [
                "Terraform", "Bicep", "Docker", "Kubernetes", "Jenkins",
                "GitHub Actions", "Azure DevOps", "GitLab CI", "Ansible",
                "CI/CD Pipelines", "GitOps", "Blue/Green Deployments",
            ],
        },
        {
            "name": "Data & Analytics",
            "icon": "fas fa-database",
            "color": "cyan",
            "skills": [
                "Microsoft Fabric", "Apache Airflow", "Power BI", "DAX",
                "Azure Synapse", "Azure Data Factory", "PostgreSQL", "MongoDB",
                "ELK Stack", "AWS Glue", "Apache Spark", "SQL",
            ],
        },
        {
            "name": "Programming",
            "icon": "fas fa-code",
            "color": "green",
            "skills": [
                "Python", "JavaScript", "TypeScript", "React", "Vue.js",
                "Node.js", "Flask", "Django", "FastAPI", "HTML5 / CSS3",
                "REST APIs", "GraphQL",
            ],
        },
        {
            "name": "Monitoring & Security",
            "icon": "fas fa-shield-alt",
            "color": "orange",
            "skills": [
                "Prometheus", "Grafana", "ELK Stack", "Azure Monitor",
                "RBAC", "Azure AD (Entra ID)", "NSG / Firewall",
                "VPN Gateway", "ExpressRoute", "Security Hardening",
            ],
        },
        {
            "name": "AI & Prompt Engineering",
            "icon": "fas fa-brain",
            "color": "pink",
            "skills": [
                "Generative AI", "OpenAI GPT", "Prompt Engineering", "Machine Learning",
                "Azure AI Services", "LLM Integration", "LangChain",
                "AI-Powered Analytics",
            ],
        },
    ],
    "projects": [
        {
            "title": "SmartInventory",
            "description": "Real-time analytics dashboard with WebSocket streaming, interactive charts, and multi-tenant support.",
            "tags": ["Python", "React", "Redis", "WebSocket"],
            "image": "project1",
            "github": "https://github.com/saikrishna1419/SmartInventory",
            "live": "#",
        },
        {
            "title": "GoodWill App",
            "description": "E-commerce platform with Stripe integration, inventory management, and automated email receipts.",
            "tags": ["Django", "Vue.js", "PostgreSQL", "Stripe"],
            "image": "project2",
            "github": "https://github.com/Aravind8331/GoodWill_APP-Project",
            "live": "#",
        },
        {
            "title": "Java & Spring Boot",
            "description": "Collaborative task manager with drag-and-drop Kanban boards, real-time sync, and Slack notifications.",
            "tags": ["Java", "Spring Boot", "REST API", "MongoDB"],
            "image": "project3",
            "github": "https://github.com/S566629/Java-and-Spring-Boot-Project",
            "live": "#",
        },
        {
            "title": "Website Creation Using AI",
            "description": "Dynamic portfolio website built using AI assistance with modern web stack — HTML, CSS, JavaScript, Node.js and Flask with responsive design and interactive animations.",
            "tags": ["HTML", "CSS", "JavaScript", "Node.js", "AI"],
            "image": "project4",
            "github": "https://github.com/S566629/s23db29Thangalla",
            "live": "#",
        },
        {
            "title": "Docker to K8s Deploy",
            "description": "AI-powered writing assistant using OpenAI GPT for blog drafts, grammar checks, and tone adjustments.",
            "tags": ["Docker", "Kubernetes", "CI/CD", "DevOps"],
            "image": "project5",
            "github": "https://github.com/S566629/Docker-image-deploy-to-k8s",
            "live": "#",
        },
        {
            "title": "Embedded Project",
            "description": "GPS fleet tracking system with geofencing alerts, route optimization, and live map visualization.",
            "tags": ["Embedded C", "IoT", "Microcontroller", "Hardware"],
            "image": "project6",
            "github": "https://github.com/S566629/Embedded-project",
            "live": "#",
        },
    ],
    "timeline": [
        {
            "year": "Apr 2025 – Present",
            "role": "Cloud Architect",
            "company": "State of Nebraska – Department of Education",
            "logo": "/static/images/nebraska_doe.png",
            "desc": (
                "Serving as the primary Cloud Architect overseeing the full Azure cloud infrastructure "
                "for a state-wide education platform. Designing and enforcing cloud governance, security "
                "baselines, and cost controls across 10+ Azure subscriptions. Leading data solutions "
                "including Azure SQL, Synapse Analytics, and Data Factory pipelines for district-level "
                "reporting. Driving server optimization and auto-scaling strategies that reduced "
                "infrastructure costs by 50% while improving system availability to 99.98% SLA. "
                "Implemented end-to-end Infrastructure as Code using Terraform, managing reusable "
                "modules for Azure resource provisioning, networking, and access policies. "
                "Containerised and deployed applications using Docker and orchestrated workloads on "
                "Azure Kubernetes Service (AKS) — enabling scalable, self-healing microservices. "
                "Led Microsoft Fabric migration, transitioning legacy data workflows into unified "
                "Fabric workspaces with Lakehouses, Data Pipelines, and Power BI Direct Lake reporting."
            ),
        },
        {
            "year": "May 2025 – Dec 2026",
            "role": "Graduate Assistant – DMAD Team",
            "company": "Northwest Missouri State University",
            "logo": "/static/images/nwmissouri.jpg",
            "desc": (
                "Contributing to the Data Management & Application Development (DMAD) team, supporting "
                "cloud infrastructure management on Azure and AWS. Designing and automating end-to-end "
                "data pipelines using Python, Azure Data Factory, and Apache Airflow. Performing data "
                "analysis and building reporting dashboards to support institutional decision-making. "
                "Collaborating with faculty and developers to modernize legacy data workflows and improve "
                "data quality across university systems."
            ),
        },
        {
            "year": "Dec 2021 – Aug 2023",
            "role": "DevOps Engineer",
            "company": "Tata Consultancy Services – OTPP Client",
            "logo": "/static/images/tcs.jpg",
            "desc": (
                "Embedded DevOps Engineer at Ontario Teachers' Pension Plan (OTPP), one of Canada's "
                "largest institutional investors. Built and maintained fully automated CI/CD pipelines "
                "using Jenkins, GitHub Actions, and Azure DevOps — reducing deployment lead time by 60%. "
                "Provisioned and managed cloud infrastructure across Azure using Terraform and Bicep IaC, "
                "enforcing GitOps practices with version-controlled infrastructure modules. "
                "Configured enterprise-grade monitoring and observability stacks using Prometheus, "
                "Grafana, and ELK — setting up alerting rules, SLO dashboards, and on-call runbooks. "
                "Managed Active Directory, Azure AD (Entra ID), RBAC policies, and hybrid network "
                "topology including VNets, NSGs, VPN Gateways, and ExpressRoute connectivity. "
                "Automated server configuration and patch management using Ansible across 200+ nodes, "
                "and contributed to incident response, capacity planning, and DR drills."
            ),
        },
        {
            "year": "Aug 2017 – Nov 2021",
            "role": "Cloud DevOps Engineer",
            "company": "Paytm E-Commerce Ltd",
            "logo": "/static/images/paytm.png",
            "desc": (
                "Worked as a Cloud DevOps Engineer at one of India's largest fintech & e-commerce "
                "platforms, managing hybrid cloud infrastructure spanning AWS, Azure, and on-premises "
                "data centers. Architected on-prem to hybrid cloud migration strategies including network "
                "design, VPN tunnels, Direct Connect, and ExpressRoute for low-latency connectivity. "
                "Provisioned and governed cloud resources using Terraform and CloudFormation IaC, "
                "maintaining reusable modules for VPCs, subnets, IAM, and security groups. "
                "Built and maintained CI/CD pipelines using Jenkins, GitLab CI, and AWS CodePipeline — "
                "enabling zero-downtime blue/green and canary deployments at scale. "
                "Implemented centralized logging and observability using the ELK Stack (Elasticsearch, "
                "Logstash, Kibana), Prometheus, and Grafana with custom alerting and SLO tracking. "
                "Designed and automated data pipelines using AWS Glue, S3, and Lambda for real-time "
                "and batch ingestion supporting analytics and fraud detection workloads. "
                "Performed data analysis, wrote complex SQL queries, built Power BI reports, and "
                "developed DAX calculations and data models for business intelligence dashboards. "
                "Collaborated closely with development teams on infrastructure sizing, cost optimization, "
                "capacity planning, and cloud security hardening across production environments."
            ),
        },
    ],
    "education": [
        {
            "degree": "Master of Science – Applied Computer Science",
            "school": "Northwest Missouri State University",
            "location": "Maryville, Missouri, USA",
            "year": "2023 - 2025",
            "logo": "/static/images/nwmissouri.jpg",
            "icon": "fas fa-university",
            "color": "purple",
            "highlights": [
                "GPA: 4.0 / 4.0",
                "Cloud Computing & Distributed Systems",
                "Data Engineering, Pipelines & Analytics",
                "Machine Learning & AI Fundamentals",
                "Applied Research in Cloud Infrastructure Automation",
            ],
        },
        {
            "degree": "Master of Business Administration",
            "school": "Sri Venkateswara University",
            "location": "Tirupati, Andhra Pradesh, India",
            "year": "2019 - 2021",
            "logo": "/static/images/svuniversity.webp",
            "icon": "fas fa-briefcase",
            "color": "gold",
            "highlights": [
                "GPA: 3.5 / 4.0",
                "Business Strategy & Operations Management",
                "IT Project Management & Agile Delivery",
                "Data-Driven Decision Making",
                "Finance & Organizational Leadership",
            ],
        },
        {
            "degree": "B.Tech – Electrical & Electronics Engineering",
            "school": "Jawaharlal Nehru Technological University",
            "location": "Anantapur, Andhra Pradesh, India",
            "year": "2014 - 2017",
            "logo": "/static/images/jntua.jpg",
            "icon": "fas fa-graduation-cap",
            "color": "cyan",
            "highlights": [
                "GPA: 3.3 / 4.0",
                "Electrical Systems, Circuits & Control Theory",
                "Embedded Systems & Microcontrollers",
                "Networking Fundamentals & Digital Electronics",
                "Final Project: IoT-based Smart Energy Monitoring System",
            ],
        },
    ],
}


@app.route("/")
def index():
    return render_template("index.html", data=PORTFOLIO_DATA)


@app.route("/contact", methods=["POST"])
def contact():
    payload = request.get_json(force=True)
    name    = payload.get("name",    "").strip()
    email   = payload.get("email",   "").strip()
    message = payload.get("message", "").strip()

    if not name or not email or not message:
        return jsonify({"success": False, "error": "All fields are required."}), 400

    # Basic email format validation
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        return jsonify({"success": False, "error": "Invalid email address."}), 400

    # ── Gmail SMTP credentials from environment variables ──
    smtp_user, smtp_pass = get_smtp_creds()
    to_email  = "saikumart9021@gmail.com"

    # Fall back to console log if credentials not configured yet
    if not smtp_user or not smtp_pass or smtp_pass == "your_16_char_app_password_here":
        # Fallback: log to console if env vars not set
        print(f"[Contact] From: {name} <{email}>\n{message}")
        return jsonify({"success": True, "message": "Thanks! I'll get back to you soon."})

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"Portfolio Contact: {name}"
        msg["From"]    = smtp_user
        msg["To"]      = to_email
        msg["Reply-To"] = email

        text_body = f"Name: {name}\nEmail: {email}\n\nMessage:\n{message}"
        html_body = f"""
        <div style="font-family:Inter,sans-serif;max-width:600px;margin:auto;background:#0f0f1a;color:#e2e8f0;border-radius:12px;overflow:hidden;">
          <div style="background:linear-gradient(135deg,#7c6dfa,#22d3ee);padding:24px 32px;">
            <h2 style="margin:0;color:#fff;font-size:1.3rem;">New Portfolio Contact</h2>
          </div>
          <div style="padding:32px;">
            <p style="margin:0 0 8px;"><strong style="color:#b79dff;">Name:</strong> {name}</p>
            <p style="margin:0 0 8px;"><strong style="color:#b79dff;">Email:</strong> <a href="mailto:{email}" style="color:#22d3ee;">{email}</a></p>
            <hr style="border:none;border-top:1px solid #2a2a4a;margin:20px 0;"/>
            <p style="margin:0 0 8px;"><strong style="color:#b79dff;">Message:</strong></p>
            <p style="margin:0;line-height:1.7;white-space:pre-wrap;">{message}</p>
          </div>
        </div>"""

        msg.attach(MIMEText(text_body, "plain"))
        msg.attach(MIMEText(html_body, "html"))

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(smtp_user, smtp_pass)
            server.sendmail(smtp_user, to_email, msg.as_string())

        return jsonify({"success": True, "message": "Thanks! I'll get back to you soon."})

    except Exception as e:
        print(f"[Contact] Email error: {e}")
        return jsonify({"success": True, "message": "Thanks! I'll get back to you soon."})


if __name__ == "__main__":
    app.run(debug=False)
